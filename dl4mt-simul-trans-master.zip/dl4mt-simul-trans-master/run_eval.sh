THEANO_FLAGS=device=gpu2 python simualtrans_eval.py --sample 1 --batchsize 1 --target 10 --sinit 1 --gamma 1 --recurrent True --Rtype 10 --coverage True 
